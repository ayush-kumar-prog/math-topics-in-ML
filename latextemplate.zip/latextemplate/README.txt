
Instructions

1. Copy template4.tex to your_poster_file.tex
2. Edit your_poster_file.tex
3. To compile:
      />pdflatex your_poster_file.tex

   If you are using BibTeX for references, then
      />pdflatex your_poster_file.tex
      />bibtex your_poster_file
      />pdflatex your_poster_file.tex


4. Iterate steps 2-4 until happy.

NOTE: Avoid using bitmap (PNG, JPG) images for figures. Use vector images where
possible. Convert them to pdf.
